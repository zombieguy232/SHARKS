var gdjs;(function(e){let c;(function(r){let i;(function(a){a.pause=function(n){n.getGame().pause(!0)},a.log=function(n,t,o){e.Logger.getLoggerOutput().log(o,n,t,!1)},a.enableDebugDraw=function(n,t,o,p,u){n.enableDebugDraw(t,o,p,u)}})(i=r.debuggerTools||(r.debuggerTools={}))})(c=e.evtTools||(e.evtTools={}))})(gdjs||(gdjs={}));
//# sourceMappingURL=debuggertools.js.map
